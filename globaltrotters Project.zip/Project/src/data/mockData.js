export const CITIES = [
  { id: 1, name: 'Paris', country: 'France', region: 'Europe', costIndex: 4, popularity: 95, imageUrl: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=400', description: 'The City of Light, known for art, fashion, and culture.' },
  { id: 2, name: 'Tokyo', country: 'Japan', region: 'Asia', costIndex: 5, popularity: 90, imageUrl: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400', description: 'A vibrant metropolis blending tradition and technology.' },
  { id: 3, name: 'New York', country: 'USA', region: 'North America', costIndex: 5, popularity: 92, imageUrl: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=400', description: 'The city that never sleeps, iconic skyline and culture.' },
  { id: 4, name: 'Bali', country: 'Indonesia', region: 'Asia', costIndex: 2, popularity: 88, imageUrl: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=400', description: 'Tropical paradise with beaches, temples, and rice terraces.' },
  { id: 5, name: 'London', country: 'UK', region: 'Europe', costIndex: 5, popularity: 93, imageUrl: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=400', description: 'Historic city with royal palaces and modern attractions.' },
  { id: 6, name: 'Dubai', country: 'UAE', region: 'Middle East', costIndex: 4, popularity: 85, imageUrl: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=400', description: 'Luxury shopping, ultramodern architecture, and nightlife.' },
  { id: 7, name: 'Barcelona', country: 'Spain', region: 'Europe', costIndex: 3, popularity: 89, imageUrl: 'https://images.unsplash.com/photo-1583422409516-2895a77efded?w=400', description: 'Gaudí architecture, beaches, and vibrant culture.' },
  { id: 8, name: 'Rome', country: 'Italy', region: 'Europe', costIndex: 3, popularity: 91, imageUrl: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=400', description: 'Ancient ruins, art, and world-class cuisine.' },
  { id: 9, name: 'Sydney', country: 'Australia', region: 'Oceania', costIndex: 4, popularity: 87, imageUrl: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=400', description: 'Harbor city with iconic opera house and beaches.' },
  { id: 10, name: 'Bangkok', country: 'Thailand', region: 'Asia', costIndex: 2, popularity: 86, imageUrl: 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?w=400', description: 'Street food, temples, and vibrant nightlife.' }
];

export const ACTIVITIES = [
  // Paris
  { id: 1, cityId: 1, name: 'Eiffel Tower Visit', type: 'sightseeing', cost: 25, duration: '2 hours', description: 'Iconic iron tower with panoramic city views.' },
  { id: 2, cityId: 1, name: 'Louvre Museum', type: 'culture', cost: 20, duration: '3 hours', description: 'World\'s largest art museum.' },
  { id: 3, cityId: 1, name: 'Seine River Cruise', type: 'sightseeing', cost: 15, duration: '1 hour', description: 'Romantic boat tour along the Seine.' },
  { id: 4, cityId: 1, name: 'French Cooking Class', type: 'food', cost: 80, duration: '4 hours', description: 'Learn to cook authentic French cuisine.' },
  
  // Tokyo
  { id: 5, cityId: 2, name: 'Senso-ji Temple', type: 'culture', cost: 0, duration: '1 hour', description: 'Ancient Buddhist temple in Asakusa.' },
  { id: 6, cityId: 2, name: 'Sushi Making Class', type: 'food', cost: 70, duration: '3 hours', description: 'Master the art of sushi.' },
  { id: 7, cityId: 2, name: 'Tokyo Skytree', type: 'sightseeing', cost: 30, duration: '2 hours', description: 'Tallest structure in Japan with stunning views.' },
  { id: 8, cityId: 2, name: 'Shibuya Crossing Tour', type: 'sightseeing', cost: 20, duration: '2 hours', description: 'Experience the world\'s busiest intersection.' },
  
  // New York
  { id: 9, cityId: 3, name: 'Statue of Liberty', type: 'sightseeing', cost: 25, duration: '3 hours', description: 'Icon of freedom and democracy.' },
  { id: 10, cityId: 3, name: 'Central Park Walk', type: 'sightseeing', cost: 0, duration: '2 hours', description: 'Urban oasis in Manhattan.' },
  { id: 11, cityId: 3, name: 'Broadway Show', type: 'culture', cost: 120, duration: '3 hours', description: 'World-class theater performance.' },
  { id: 12, cityId: 3, name: 'Food Tour', type: 'food', cost: 60, duration: '4 hours', description: 'Taste iconic NYC foods.' },
  
  // Bali
  { id: 13, cityId: 4, name: 'Uluwatu Temple', type: 'culture', cost: 5, duration: '2 hours', description: 'Clifftop temple with sunset views.' },
  { id: 14, cityId: 4, name: 'Surfing Lesson', type: 'adventure', cost: 40, duration: '2 hours', description: 'Ride the waves of Bali.' },
  { id: 15, cityId: 4, name: 'Rice Terrace Trek', type: 'adventure', cost: 30, duration: 'Half day', description: 'Hike through stunning terraces.' },
  { id: 16, cityId: 4, name: 'Balinese Cooking', type: 'food', cost: 35, duration: '3 hours', description: 'Learn traditional recipes.' },
  
  // London
  { id: 17, cityId: 5, name: 'Big Ben & Parliament', type: 'sightseeing', cost: 20, duration: '2 hours', description: 'Iconic clock tower and government buildings.' },
  { id: 18, cityId: 5, name: 'British Museum', type: 'culture', cost: 0, duration: '3 hours', description: 'World history and culture.' },
  { id: 19, cityId: 5, name: 'Thames River Cruise', type: 'sightseeing', cost: 25, duration: '1.5 hours', description: 'See London from the water.' },
  { id: 20, cityId: 5, name: 'Afternoon Tea', type: 'food', cost: 50, duration: '2 hours', description: 'Traditional British tea experience.' }
];