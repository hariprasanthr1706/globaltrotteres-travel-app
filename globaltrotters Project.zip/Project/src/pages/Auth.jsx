import React, { useState } from 'react';
import { Plane } from 'lucide-react';
import { Card, Input, Button } from '../components/shared';
import { storage } from '../utils/storage';

export default function Auth({ onLogin }) {
  const [authMode, setAuthMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [authError, setAuthError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    setAuthError('');
    
    if (!email || !password) {
      setAuthError('Please fill in all fields');
      return;
    }
    
    const user = { id: storage.generateId(), name: email.split('@')[0], email };
    storage.setUser(user);
    onLogin(user);
  };

  const handleSignup = (e) => {
    e.preventDefault();
    setAuthError('');
    
    if (!name || !email || !password) {
      setAuthError('Please fill in all fields');
      return;
    }
    
    if (password.length < 6) {
      setAuthError('Password must be at least 6 characters');
      return;
    }
    
    const user = { id: storage.generateId(), name, email };
    storage.setUser(user);
    onLogin(user);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="flex justify-center mb-4">
            <Plane className="text-blue-600" size={48} />
          </div>
          <h2 className="text-2xl font-bold">Welcome to GlobeTrotter</h2>
          <p className="text-gray-600">Plan your perfect journey</p>
        </div>
        
        <div className="flex space-x-2 mb-6">
          <button onClick={() => setAuthMode('login')} className={`flex-1 py-2 rounded-lg ${authMode === 'login' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}>Login</button>
          <button onClick={() => setAuthMode('signup')} className={`flex-1 py-2 rounded-lg ${authMode === 'signup' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}>Sign Up</button>
        </div>
        
        <form onSubmit={authMode === 'login' ? handleLogin : handleSignup}>
          {authMode === 'signup' && (
            <Input label="Name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" required />
          )}
          <Input label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required />
          <Input label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required />
          
          {authError && <p className="text-red-500 text-sm mb-4">{authError}</p>}
          
          <Button variant="primary" className="w-full">{authMode === 'login' ? 'Login' : 'Create Account'}</Button>
        </form>
      </Card>
    </div>
  );
}