import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { MapPin, DollarSign, Star, Plus, Filter, CheckCircle } from 'lucide-react';
import { SearchBar, Card, Button, Modal, ActivityCard } from '../components/shared';
import { CITIES, ACTIVITIES } from '../mockData';
import { getTrips, saveTrip, getUser, generateId } from '../utils/storage';

const Search = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const queryParams = new URLSearchParams(location.search);
  const cityIdParam = queryParams.get('city');
  const mode = location.pathname.includes('/activities') ? 'ACTIVITY' : 'CITY';

  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCountry, setFilterCountry] = useState('All');
  const [filterCost, setFilterCost] = useState('All');
  const [filterType, setFilterType] = useState('All');
  const [maxPrice, setMaxPrice] = useState(200);
  
  const [selectedItem, setSelectedItem] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [userTrips, setUserTrips] = useState([]);
  const [selectedTripId, setSelectedTripId] = useState('');

  useEffect(() => {
    const currentUser = getUser();
    if (currentUser) {
      setUser(currentUser);
      setUserTrips(getTrips(currentUser.id));
    }
  }, []);

  const countries = ['All', ...new Set(CITIES.map(c => c.country))];
  const activityTypes = ['All', 'sightseeing', 'food', 'adventure', 'culture'];

  const filteredCities = CITIES.filter(city => {
    const matchesName = city.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCountry = filterCountry === 'All' || city.country === filterCountry;
    const matchesCost = filterCost === 'All' || city.costIndex === parseInt(filterCost);
    return matchesName && matchesCountry && matchesCost;
  });

  const filteredActivities = ACTIVITIES.filter(act => {
    const matchesCity = !cityIdParam || act.cityId === parseInt(cityIdParam);
    const matchesType = filterType === 'All' || act.type === filterType;
    const matchesPrice = act.cost <= maxPrice;
    const matchesSearch = act.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCity && matchesType && matchesPrice && matchesSearch;
  });

  const handleAddToTrip = (item) => {
    if (!user) {
      navigate('/auth');
      return;
    }
    setSelectedItem(item);
    setIsModalOpen(true);
  };

  const confirmAddCity = (tripId) => {
    const trip = userTrips.find(t => t.id === tripId);
    if (trip) {
      const newStop = {
        id: generateId(),
        cityId: selectedItem.id,
        cityName: selectedItem.name,
        arrival: trip.startDate,
        departure: trip.startDate,
        activities: []
      };
      trip.stops.push(newStop);
      saveTrip(trip);
      alert(`${selectedItem.name} added to ${trip.name}`);
      setIsModalOpen(false);
    }
  };

  const confirmAddActivity = (tripId, stopId) => {
    const trip = userTrips.find(t => t.id === tripId);
    if (trip) {
      const stop = trip.stops.find(s => s.id === stopId);
      if (stop) {
        stop.activities.push(selectedItem);
        saveTrip(trip);
        alert(`${selectedItem.name} added to ${stop.cityName}`);
        setIsModalOpen(false);
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 animate-fadeIn">
      {/* Header & Main Search */}
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-extrabold text-gray-900 mb-4">
          {mode === 'CITY' ? 'Explore Destinations' : 'Plan Your Activities'}
        </h1>
        <div className="max-w-2xl mx-auto">
          <SearchBar 
            placeholder={mode === 'CITY' ? "Search cities (e.g. Paris, Tokyo)..." : "Search activities..."} 
            value={searchTerm} 
            onChange={setSearchTerm} 
          />
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters Sidebar */}
        <aside className="lg:w-64 space-y-8">
          <div className="bg-white p-6 rounded-2xl card-shadow border border-gray-100">
            <h3 className="flex items-center gap-2 font-bold text-gray-900 mb-4">
              <Filter size={18} /> Filters
            </h3>
            
            {mode === 'CITY' ? (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-gray-400 uppercase">Country</label>
                  <select 
                    className="w-full mt-1 p-2 bg-gray-50 border-none rounded-lg text-sm"
                    value={filterCountry}
                    onChange={(e) => setFilterCountry(e.target.value)}
                  >
                    {countries.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-400 uppercase">Cost Level</label>
                  <select 
                    className="w-full mt-1 p-2 bg-gray-50 border-none rounded-lg text-sm"
                    value={filterCost}
                    onChange={(e) => setFilterCost(e.target.value)}
                  >
                    <option value="All">All Price Points</option>
                    {[1, 2, 3, 4, 5].map(n => <option key={n} value={n}>{'$'.repeat(n)}</option>)}
                  </select>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-gray-400 uppercase">Category</label>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {activityTypes.map(type => (
                      <button
                        key={type}
                        onClick={() => setFilterType(type)}
                        className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                          filterType === type ? 'bg-primary text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                      >
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex justify-between">
                    <label className="text-xs font-semibold text-gray-400 uppercase">Max Price</label>
                    <span className="text-xs font-bold text-primary">${maxPrice}</span>
                  </div>
                  <input 
                    type="range" min="0" max="200" step="10"
                    className="w-full mt-2 accent-primary"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(parseInt(e.target.value))}
                  />
                </div>
              </div>
            )}
          </div>
        </aside>

        {/* Results Grid */}
        <main className="flex-1">
          {mode === 'CITY' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCities.map(city => (
                <div key={city.id} className="group bg-white rounded-2xl overflow-hidden card-shadow hover:-translate-y-1 transition-all">
                  <div className="relative h-48">
                    <img src={city.imageUrl} alt={city.name} className="w-full h-full object-cover" />
                    <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1">
                      <Star size={12} className="fill-yellow-400 text-yellow-400" /> {city.popularity}
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="text-xl font-bold text-gray-900">{city.name}</h3>
                    <p className="text-secondary text-sm flex items-center gap-1 mb-3">
                      <MapPin size={14} /> {city.country}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-primary font-medium">{'$'.repeat(city.costIndex)}</span>
                      <Button 
                        size="sm" 
                        onClick={() => handleAddToTrip(city)}
                        className="bg-primary text-white"
                      >
                        Add to Trip
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredActivities.map(act => (
                <ActivityCard 
                  key={act.id} 
                  activity={act} 
                  onAction={() => handleAddToTrip(act)}
                  actionLabel="Add to Trip"
                />
              ))}
            </div>
          )}
        </main>
      </div>

      {/* Add to Trip Modal */}
      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={mode === 'CITY' ? "Add City to Trip" : "Add Activity to Stop"}
      >
        <div className="space-y-4">
          <p className="text-sm text-secondary">Choose which itinerary to update:</p>
          <div className="max-h-60 overflow-y-auto space-y-2 pr-2">
            {userTrips.length > 0 ? (
              userTrips.map(trip => (
                <div key={trip.id} className="border rounded-xl p-3 hover:border-primary cursor-pointer transition-colors">
                  <div 
                    className="flex items-center justify-between"
                    onClick={() => setSelectedTripId(selectedTripId === trip.id ? '' : trip.id)}
                  >
                    <div>
                      <p className="font-bold text-gray-900">{trip.name}</p>
                      <p className="text-xs text-secondary">{trip.stops.length} stops</p>
                    </div>
                    {selectedTripId === trip.id && <CheckCircle size={20} className="text-primary" />}
                    {mode === 'CITY' && selectedTripId !== trip.id && (
                      <Button size="sm" onClick={(e) => { e.stopPropagation(); confirmAddCity(trip.id); }}>Add</Button>
                    )}
                  </div>

                  {/* Show stops if adding activity */}
                  {mode === 'ACTIVITY' && selectedTripId === trip.id && (
                    <div className="mt-3 pt-3 border-t grid grid-cols-1 gap-2">
                      {trip.stops.length > 0 ? (
                        trip.stops.map(stop => (
                          <button
                            key={stop.id}
                            className="text-left text-sm p-2 rounded-lg bg-gray-50 hover:bg-primary hover:text-white transition-colors flex justify-between items-center"
                            onClick={() => confirmAddActivity(trip.id, stop.id)}
                          >
                            <span>{stop.cityName}</span>
                            <Plus size={14} />
                          </button>
                        ))
                      ) : (
                        <p className="text-xs text-red-500 italic">No stops in this trip yet.</p>
                      )}
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-4">
                <p className="text-sm text-secondary mb-3">No trips found.</p>
                <Button onClick={() => navigate('/trip/new')}>Create New Trip</Button>
              </div>
            )}
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default Search;