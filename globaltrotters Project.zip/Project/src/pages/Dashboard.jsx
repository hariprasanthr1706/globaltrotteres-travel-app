import React from 'react';
import { Calendar, MapPin, DollarSign, Plus, Star } from 'lucide-react';
import { Card, Button, TripCard, Modal } from '../components/shared';
import { CITIES } from '../data/mockData';

export default function Dashboard({ currentUser, trips, onNavigate, onDeleteTrip }) {
  const [deleteConfirm, setDeleteConfirm] = React.useState(null);

  const calculateTripCost = (trip) => {
    let total = 0;
    trip.stops?.forEach(stop => {
      stop.activities?.forEach(activity => {
        total += activity.cost || 0;
      });
    });
    return total;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome back, {currentUser.name}! 👋</h1>
          <p className="text-gray-600">Ready to plan your next adventure?</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Total Trips</p>
                <p className="text-3xl font-bold text-blue-600">{trips.length}</p>
              </div>
              <Calendar size={40} className="text-blue-600" />
            </div>
          </Card>
          
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Cities Visited</p>
                <p className="text-3xl font-bold text-green-600">{trips.reduce((acc, t) => acc + (t.stops?.length || 0), 0)}</p>
              </div>
              <MapPin size={40} className="text-green-600" />
            </div>
          </Card>
          
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Total Budget</p>
                <p className="text-3xl font-bold text-purple-600">${trips.reduce((acc, t) => acc + calculateTripCost(t), 0)}</p>
              </div>
              <DollarSign size={40} className="text-purple-600" />
            </div>
          </Card>
        </div>
        
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Your Recent Trips</h2>
            <Button onClick={() => onNavigate('create-trip')}>
              <Plus size={18} className="mr-1 inline" /> Plan New Trip
            </Button>
          </div>
          
          {trips.length === 0 ? (
            <Card>
              <div className="text-center py-12">
                <MapPin size={48} className="mx-auto text-gray-400 mb-4" />
                <p className="text-gray-600 mb-4">No trips yet. Start planning your first adventure!</p>
                <Button onClick={() => onNavigate('create-trip')}>Create Your First Trip</Button>
              </div>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trips.slice(0, 3).map(trip => (
                <TripCard
                  key={trip.id}
                  trip={trip}
                  onClick={() => onNavigate('view-trip', trip)}
                  onEdit={() => onNavigate('edit-trip', trip)}
                  onDelete={() => setDeleteConfirm(trip.id)}
                />
              ))}
            </div>
          )}
        </div>
        
        <div>
          <h2 className="text-2xl font-bold mb-4">Popular Destinations</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {CITIES.slice(0, 8).map(city => (
              <div key={city.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                <div className="h-32" style={{ backgroundImage: `url(${city.imageUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
                <div className="p-3">
                  <h3 className="font-semibold">{city.name}</h3>
                  <p className="text-sm text-gray-600">{city.country}</p>
                  <div className="flex items-center mt-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={12} className={i < city.costIndex ? 'text-yellow-400 fill-current' : 'text-gray-300'} />
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <Modal isOpen={deleteConfirm !== null} onClose={() => setDeleteConfirm(null)} title="Delete Trip">
        <p className="mb-4">Are you sure you want to delete this trip? This action cannot be undone.</p>
        <div className="flex space-x-4">
          <Button variant="secondary" onClick={() => setDeleteConfirm(null)}>Cancel</Button>
          <Button variant="danger" onClick={() => { onDeleteTrip(deleteConfirm); setDeleteConfirm(null); }}>Delete Trip</Button>
        </div>
      </Modal>
    </div>
  );
}