import React, { useState } from 'react';
import { ArrowLeft, Plus, Trash, Edit } from 'lucide-react';
import { Card, Input, Button, Modal, TripCard, ActivityCard } from '../components/shared';
import { CITIES, ACTIVITIES } from '../data/mockData';
import { storage } from '../utils/storage';

export default function TripManager({ mode, currentUser, trips, selectedTrip, onBack, onSave, onDelete }) {
  const [tripForm, setTripForm] = useState(
    selectedTrip || { name: '', startDate: '', endDate: '', description: '', stops: [] }
  );
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState('');
  const [selectedStop, setSelectedStop] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const handleCreateTrip = (e) => {
    e.preventDefault();
    if (!tripForm.name || !tripForm.startDate || !tripForm.endDate) return;
    
    const newTrip = {
      id: storage.generateId(),
      userId: currentUser.id,
      ...tripForm,
      stops: [],
      createdAt: Date.now()
    };
    
    onSave(newTrip, 'edit');
  };

  const handleAddStop = (city) => {
    const newStop = {
      id: storage.generateId(),
      cityId: city.id,
      cityName: city.name,
      startDate: tripForm.startDate,
      endDate: tripForm.endDate,
      activities: []
    };
    
    setTripForm({
      ...tripForm,
      stops: [...tripForm.stops, newStop]
    });
    setIsModalOpen(false);
  };

  const handleAddActivity = (activity) => {
    const updatedStops = tripForm.stops.map(stop => {
      if (stop.id === selectedStop.id) {
        return {
          ...stop,
          activities: [...stop.activities, { ...activity, id: storage.generateId() }]
        };
      }
      return stop;
    });
    
    setTripForm({ ...tripForm, stops: updatedStops });
    setIsModalOpen(false);
  };

  const handleDeleteActivity = (stopId, activityId) => {
    const updatedStops = tripForm.stops.map(stop => {
      if (stop.id === stopId) {
        return {
          ...stop,
          activities: stop.activities.filter(a => a.id !== activityId)
        };
      }
      return stop;
    });
    
    setTripForm({ ...tripForm, stops: updatedStops });
  };

  const handleDeleteStop = (stopId) => {
    setTripForm({
      ...tripForm,
      stops: tripForm.stops.filter(s => s.id !== stopId)
    });
  };

  const handleSaveTrip = () => {
    onSave(tripForm);
  };

  const filteredCities = CITIES.filter(city =>
    city.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    city.country.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // LIST MODE - Show all trips
  if (mode === 'list') {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">My Trips</h1>
            <Button onClick={() => onBack('create-trip')}>
              <Plus size={18} className="mr-1 inline" /> Create New Trip
            </Button>
          </div>
          
          {trips.length === 0 ? (
            <Card>
              <div className="text-center py-12">
                <p className="text-gray-600 mb-4">No trips yet. Create your first trip!</p>
                <Button onClick={() => onBack('create-trip')}>Create Trip</Button>
              </div>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trips.map(trip => (
                <TripCard
                  key={trip.id}
                  trip={trip}
                  onClick={() => onBack('view-trip', trip)}
                  onEdit={() => onBack('edit-trip', trip)}
                  onDelete={() => setDeleteConfirm(trip.id)}
                />
              ))}
            </div>
          )}
        </div>
        
        <Modal isOpen={deleteConfirm !== null} onClose={() => setDeleteConfirm(null)} title="Delete Trip">
          <p className="mb-4">Are you sure you want to delete this trip?</p>
          <div className="flex space-x-4">
            <Button variant="secondary" onClick={() => setDeleteConfirm(null)}>Cancel</Button>
            <Button variant="danger" onClick={() => { onDelete(deleteConfirm); setDeleteConfirm(null); }}>Delete</Button>
          </div>
        </Modal>
      </div>
    );
  }

  // CREATE MODE - New trip form
  if (mode === 'create') {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-3xl mx-auto px-4 py-8">
          <button onClick={() => onBack('dashboard')} className="flex items-center text-blue-600 mb-6 hover:text-blue-700">
            <ArrowLeft size={20} className="mr-1" /> Back to Dashboard
          </button>
          
          <Card title="Create New Trip">
            <form onSubmit={handleCreateTrip}>
              <Input
                label="Trip Name"
                value={tripForm.name}
                onChange={(e) => setTripForm({ ...tripForm, name: e.target.value })}
                placeholder="My Amazing Adventure"
                required
              />
              
              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="Start Date"
                  type="date"
                  value={tripForm.startDate}
                  onChange={(e) => setTripForm({ ...tripForm, startDate: e.target.value })}
                  required
                />
                <Input
                  label="End Date"
                  type="date"
                  value={tripForm.endDate}
                  onChange={(e) => setTripForm({ ...tripForm, endDate: e.target.value })}
                  required
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={tripForm.description}
                  onChange={(e) => setTripForm({ ...tripForm, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  rows="3"
                  placeholder="Describe your trip..."
                />
              </div>
              
              <div className="flex space-x-4">
                <Button variant="secondary" onClick={() => onBack('dashboard')}>Cancel</Button>
                <Button variant="primary">Create Trip</Button>
              </div>
            </form>
          </Card>
        </div>
      </div>
    );
  }

  // EDIT MODE - Edit trip and add stops/activities
  if (mode === 'edit') {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <button onClick={() => onBack('trips')} className="flex items-center text-blue-600 mb-6 hover:text-blue-700">
            <ArrowLeft size={20} className="mr-1" /> Back to Trips
          </button>
          
          <Card className="mb-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h1 className="text-2xl font-bold">{tripForm.name}</h1>
                <p className="text-gray-600">
                  {new Date(tripForm.startDate).toLocaleDateString()} - {new Date(tripForm.endDate).toLocaleDateString()}
                </p>
              </div>
              <Button onClick={handleSaveTrip}>Save Changes</Button>
            </div>
          </Card>

          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Itinerary</h2>
              <Button onClick={() => { setModalType('add-stop'); setIsModalOpen(true); }}>
                <Plus size={18} className="mr-1 inline" /> Add Stop
              </Button>
            </div>

            {tripForm.stops.length === 0 ? (
              <Card>
                <div className="text-center py-8">
                  <p className="text-gray-600 mb-4">No stops yet. Add your first destination!</p>
                  <Button onClick={() => { setModalType('add-stop'); setIsModalOpen(true); }}>Add Stop</Button>
                </div>
              </Card>
            ) : (
              <div className="space-y-4">
                {tripForm.stops.map((stop, index) => (
                  <Card key={stop.id}>
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-lg font-semibold">Stop {index + 1}: {stop.cityName}</h3>
                        <p className="text-sm text-gray-600">
                          {new Date(stop.startDate).toLocaleDateString()} - {new Date(stop.endDate).toLocaleDateString()}
                        </p>
                      </div>
                      <button onClick={() => handleDeleteStop(stop.id)} className="text-red-600 hover:text-red-700">
                        <Trash size={18} />
                      </button>
                    </div>

                    <div className="mb-3">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-medium">Activities</h4>
                        <Button 
                          variant="secondary" 
                          onClick={() => { 
                            setSelectedStop(stop); 
                            setModalType('add-activity'); 
                            setIsModalOpen(true); 
                          }}
                        >
                          <Plus size={16} className="mr-1 inline" /> Add Activity
                        </Button>
                      </div>

                      {stop.activities.length === 0 ? (
                        <p className="text-gray-500 text-sm">No activities yet</p>
                      ) : (
                        <div className="space-y-2">
                          {stop.activities.map(activity => (
                            <div key={activity.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                              <div>
                                <p className="font-medium">{activity.name}</p>
                                <p className="text-sm text-gray-600">{activity.duration} • ${activity.cost}</p>
                              </div>
                              <button 
                                onClick={() => handleDeleteActivity(stop.id, activity.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash size={16} />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Add Stop Modal */}
        <Modal 
          isOpen={isModalOpen && modalType === 'add-stop'} 
          onClose={() => setIsModalOpen(false)} 
          title="Add Destination"
        >
          <input
            type="text"
            placeholder="Search cities..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg mb-4"
          />
          <div className="grid grid-cols-2 gap-4 max-h-96 overflow-y-auto">
            {filteredCities.map(city => (
              <div 
                key={city.id} 
                className="border rounded-lg p-3 cursor-pointer hover:border-blue-500 transition-colors"
                onClick={() => handleAddStop(city)}
              >
                <div className="h-24 mb-2 rounded" style={{ backgroundImage: `url(${city.imageUrl})`, backgroundSize: 'cover' }} />
                <h4 className="font-semibold">{city.name}</h4>
                <p className="text-sm text-gray-600">{city.country}</p>
              </div>
            ))}
          </div>
        </Modal>

        {/* Add Activity Modal */}
        <Modal 
          isOpen={isModalOpen && modalType === 'add-activity'} 
          onClose={() => setIsModalOpen(false)} 
          title={`Add Activity in ${selectedStop?.cityName}`}
        >
          <div className="grid grid-cols-1 gap-4 max-h-96 overflow-y-auto">
            {ACTIVITIES.filter(a => a.cityId === selectedStop?.cityId).map(activity => (
              <ActivityCard
                key={activity.id}
                activity={activity}
                onAdd={() => handleAddActivity(activity)}
                isAdded={selectedStop?.activities.some(a => a.name === activity.name)}
              />
            ))}
          </div>
        </Modal>
      </div>
    );
  }

  return null;
}