import React, { useState } from 'react';
import { ArrowLeft, Calendar, MapPin, DollarSign, Clock, Edit } from 'lucide-react';
import { Card, Button, TimelineDay } from '../components/shared';

export default function ItineraryView({ trip, onBack, onEdit }) {
  const [activeTab, setActiveTab] = useState('overview');

  const calculateTripCost = () => {
    let total = 0;
    trip.stops?.forEach(stop => {
      stop.activities?.forEach(activity => {
        total += activity.cost || 0;
      });
    });
    return total;
  };

  const getTripStats = () => {
    const startDate = new Date(trip.startDate);
    const endDate = new Date(trip.endDate);
    const days = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1;
    const cities = trip.stops?.length || 0;
    const activities = trip.stops?.reduce((acc, stop) => acc + (stop.activities?.length || 0), 0) || 0;
    
    return { days, cities, activities };
  };

  const getDayByDayActivities = () => {
    const activities = [];
    trip.stops?.forEach(stop => {
      stop.activities?.forEach(activity => {
        activities.push({
          date: stop.startDate,
          city: stop.cityName,
          ...activity
        });
      });
    });
    
    // Group by date
    const grouped = activities.reduce((acc, activity) => {
      const date = activity.date;
      if (!acc[date]) acc[date] = [];
      acc[date].push(activity);
      return acc;
    }, {});
    
    return Object.entries(grouped).sort((a, b) => new Date(a[0]) - new Date(b[0]));
  };

  const stats = getTripStats();
  const totalCost = calculateTripCost();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <button onClick={() => onBack('trips')} className="flex items-center text-blue-600 mb-6 hover:text-blue-700">
          <ArrowLeft size={20} className="mr-1" /> Back to Trips
        </button>

        {/* Trip Header */}
        <Card className="mb-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold mb-2">{trip.name}</h1>
              <div className="flex items-center text-gray-600 mb-2">
                <Calendar size={18} className="mr-2" />
                <span>
                  {new Date(trip.startDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })} - 
                  {new Date(trip.endDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </span>
              </div>
              {trip.description && <p className="text-gray-600">{trip.description}</p>}
            </div>
            <Button onClick={onEdit}>
              <Edit size={18} className="mr-1 inline" /> Edit Trip
            </Button>
          </div>
        </Card>

        {/* Tabs */}
        <div className="flex space-x-2 mb-6 border-b">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 font-medium ${activeTab === 'overview' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-600'}`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('timeline')}
            className={`px-4 py-2 font-medium ${activeTab === 'timeline' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-600'}`}
          >
            Timeline
          </button>
          <button
            onClick={() => setActiveTab('budget')}
            className={`px-4 py-2 font-medium ${activeTab === 'budget' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-600'}`}
          >
            Budget
          </button>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div>
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <div className="text-center">
                  <Calendar size={32} className="mx-auto text-blue-600 mb-2" />
                  <p className="text-2xl font-bold">{stats.days}</p>
                  <p className="text-gray-600 text-sm">Days</p>
                </div>
              </Card>
              <Card>
                <div className="text-center">
                  <MapPin size={32} className="mx-auto text-green-600 mb-2" />
                  <p className="text-2xl font-bold">{stats.cities}</p>
                  <p className="text-gray-600 text-sm">Cities</p>
                </div>
              </Card>
              <Card>
                <div className="text-center">
                  <Clock size={32} className="mx-auto text-purple-600 mb-2" />
                  <p className="text-2xl font-bold">{stats.activities}</p>
                  <p className="text-gray-600 text-sm">Activities</p>
                </div>
              </Card>
              <Card>
                <div className="text-center">
                  <DollarSign size={32} className="mx-auto text-orange-600 mb-2" />
                  <p className="text-2xl font-bold">${totalCost}</p>
                  <p className="text-gray-600 text-sm">Est. Cost</p>
                </div>
              </Card>
            </div>

            {/* Stops */}
            <h2 className="text-2xl font-bold mb-4">Itinerary</h2>
            {trip.stops?.length === 0 ? (
              <Card>
                <p className="text-center text-gray-600 py-8">No stops added yet</p>
              </Card>
            ) : (
              <div className="space-y-4">
                {trip.stops?.map((stop, index) => (
                  <Card key={stop.id}>
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-semibold">Stop {index + 1}: {stop.cityName}</h3>
                        <p className="text-gray-600">
                          {new Date(stop.startDate).toLocaleDateString()} - {new Date(stop.endDate).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">{stop.activities?.length || 0} activities</p>
                        <p className="font-semibold text-green-600">
                          ${stop.activities?.reduce((acc, a) => acc + (a.cost || 0), 0) || 0}
                        </p>
                      </div>
                    </div>

                    {stop.activities?.length > 0 && (
                      <div className="space-y-2">
                        {stop.activities.map(activity => (
                          <div key={activity.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <div>
                              <p className="font-medium">{activity.name}</p>
                              <p className="text-sm text-gray-600 capitalize">{activity.type} • {activity.duration}</p>
                            </div>
                            <p className="font-semibold text-green-600">${activity.cost}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Timeline Tab */}
        {activeTab === 'timeline' && (
          <div>
            <h2 className="text-2xl font-bold mb-4">Day-by-Day Timeline</h2>
            {getDayByDayActivities().length === 0 ? (
              <Card>
                <p className="text-center text-gray-600 py-8">No activities scheduled yet</p>
              </Card>
            ) : (
              <Card>
                {getDayByDayActivities().map(([date, activities]) => (
                  <TimelineDay key={date} date={date} activities={activities} />
                ))}
              </Card>
            )}
          </div>
        )}

        {/* Budget Tab */}
        {activeTab === 'budget' && (
          <div>
            <h2 className="text-2xl font-bold mb-4">Budget Breakdown</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card title="Cost Summary">
                <div className="space-y-3">
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-medium">Activities</span>
                    <span className="text-green-600 font-semibold">${totalCost}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-medium">Transport (Est.)</span>
                    <span className="text-green-600 font-semibold">${(stats.cities * 50)}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-medium">Accommodation (Est.)</span>
                    <span className="text-green-600 font-semibold">${(stats.days * 100)}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b">
                    <span className="font-medium">Meals (Est.)</span>
                    <span className="text-green-600 font-semibold">${(stats.days * 50)}</span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-t-2">
                    <span className="font-bold text-lg">Total</span>
                    <span className="text-blue-600 font-bold text-xl">
                      ${totalCost + (stats.cities * 50) + (stats.days * 100) + (stats.days * 50)}
                    </span>
                  </div>
                </div>
              </Card>

              <Card title="Daily Average">
                <div className="text-center py-8">
                  <DollarSign size={48} className="mx-auto text-blue-600 mb-4" />
                  <p className="text-4xl font-bold text-blue-600 mb-2">
                    ${Math.round((totalCost + (stats.cities * 50) + (stats.days * 100) + (stats.days * 50)) / stats.days)}
                  </p>
                  <p className="text-gray-600">per day</p>
                </div>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}