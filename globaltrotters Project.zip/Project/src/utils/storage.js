export const storage = {
  getUser: () => {
    const user = localStorage.getItem('globetrotter_user');
    return user ? JSON.parse(user) : null;
  },
  setUser: (user) => {
    localStorage.setItem('globetrotter_user', JSON.stringify(user));
  },
  clearUser: () => {
    localStorage.removeItem('globetrotter_user');
  },
  getTrips: (userId) => {
    const trips = localStorage.getItem('globetrotter_trips');
    const allTrips = trips ? JSON.parse(trips) : [];
    return allTrips.filter(t => t.userId === userId);
  },
  getTripById: (tripId) => {
    const trips = localStorage.getItem('globetrotter_trips');
    const allTrips = trips ? JSON.parse(trips) : [];
    return allTrips.find(t => t.id === tripId);
  },
  saveTrip: (trip) => {
    const trips = localStorage.getItem('globetrotter_trips');
    const allTrips = trips ? JSON.parse(trips) : [];
    const existingIndex = allTrips.findIndex(t => t.id === trip.id);
    
    if (existingIndex >= 0) {
      allTrips[existingIndex] = trip;
    } else {
      allTrips.push(trip);
    }
    
    localStorage.setItem('globetrotter_trips', JSON.stringify(allTrips));
    return trip;
  },
  deleteTrip: (tripId) => {
    const trips = localStorage.getItem('globetrotter_trips');
    const allTrips = trips ? JSON.parse(trips) : [];
    const filtered = allTrips.filter(t => t.id !== tripId);
    localStorage.setItem('globetrotter_trips', JSON.stringify(filtered));
  },
  generateId: () => Date.now() + Math.random()
};