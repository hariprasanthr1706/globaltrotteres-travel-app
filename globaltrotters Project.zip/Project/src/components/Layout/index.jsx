import React from 'react';
import { Navigate, Outlet, Link, useNavigate } from 'react-router-dom';
import { getUser, logout } from '../utils/storage';
import { Globe, Layout as LayoutIcon, Map, Search, LogOut } from 'lucide-react';

// Security check component
export const ProtectedRoute = () => {
  const user = getUser();
  return user ? <Outlet /> : <Navigate to="/login" replace />;
};

// Main wrapper with Sidebar
export const MainLayout = () => {
  const navigate = useNavigate();
  const user = getUser();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-6 flex items-center gap-2 text-primary">
          <Globe size={28} className="font-bold" />
          <span className="text-xl font-bold tracking-tight text-gray-900">GlobeTrotter</span>
        </div>
        
        <nav className="flex-1 px-4 space-y-2">
          <Link to="/dashboard" className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-100 text-gray-700 font-medium transition-colors">
            <LayoutIcon size={20} /> Dashboard
          </Link>
          <Link to="/trips" className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-100 text-gray-700 font-medium transition-colors">
            <Map size={20} /> My Trips
          </Link>
          <Link to="/search/cities" className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-100 text-gray-700 font-medium transition-colors">
            <Search size={20} /> Explore
          </Link>
        </nav>

        <div className="p-4 border-t">
          <div className="flex items-center gap-3 mb-4 px-2">
            <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center font-bold">
              {user?.name?.charAt(0)}
            </div>
            <div className="truncate">
              <p className="text-sm font-bold text-gray-900 truncate">{user?.name}</p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 p-3 rounded-xl text-red-500 hover:bg-red-50 font-medium transition-colors"
          >
            <LogOut size={20} /> Logout
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
};