import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { MainLayout, ProtectedRoute } from './components/Layout';
import Auth from './pages/Auth';
import Dashboard from './pages/Dashboard';
import TripManager from './pages/TripManager';
import ItineraryView from './pages/ItineraryView';
import Search from './pages/Search';

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Auth />} />
        <Route path="/signup" element={<Auth />} />

        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<MainLayout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/trips" element={<TripManager />} />
            <Route path="/trip/new" element={<TripManager />} />
            <Route path="/trip/:id" element={<ItineraryView />} />
            <Route path="/trip/:id/edit" element={<TripManager />} />
            <Route path="/search/cities" element={<Search />} />
            <Route path="/search/activities" element={<Search />} />
          </Route>
        </Route>

        {/* Redirects */}
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;